/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical4car;

/**
 *
 * @author М_З_А
 */
public class Practical4Car {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
